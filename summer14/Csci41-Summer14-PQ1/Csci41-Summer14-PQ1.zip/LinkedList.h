/*
 *  LinkedList.h
 *  Csci41-S13-PQuiz1-Thur
 *
 *  Created by shliu on 2/18/13.
 *  Copyright 2013 __MyCompanyName__. All rights reserved.
 *
 */
/*
 implement a *Singly* Linked List class that has
 
 1. pop_front: delete from the front of the linked list  
 2. pop_back: delete the last node of the linked list
 3. front as a data member points to its first node
  
 the above four are required!
 
 You may add more functions or data members to support Stack class 
 */
#ifndef LinkedList_H
#define LinkedList_H
#include "Node.h"
#include <iostream>
using namespace std;
class LinkedList
{

public:
	LinkedList()
	{
		front = NULL;
		size = 0;
	}
	void push_front(int item)
	{
		if (front == NULL)
		{
			front = new Node(NULL, item);
			size++;
			return; 
		}
		
		Node* newNode = new Node(NULL, item);
		newNode->next = front;
		front = newNode;
		size++;
		
	}
	
	int pop_front()
	{
		//add contents here...
	}
	
	int pop_back()
	{
		//add contents here.		
	}
	void push_back(int item)
	{
		//assuming available

	}

	void print()
	{
		//assuming available
	}
private:
	Node* front; //front of a linked list
	int size; //# of nodes in a linked list
};
#endif LinkedList_H