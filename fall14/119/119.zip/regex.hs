-- Regular expressions
import Control.Applicative
import Data.Maybe (isJust)  
import Debug.Trace (trace)

data RE = Empty | Letter Char | Union RE RE | Cat RE RE | Star RE
instance (Show RE) where    -- use precedence to minimize parentheses
  showsPrec d Empty         = showString "@"
  showsPrec d (Letter c)    = showString [c]
  showsPrec d (Union r1 r2) = showParen (d > 6) $  -- prec(Union) = 6
                              showsPrec 6 r1 .
                              showString "+" .
                              showsPrec 6 r2
  showsPrec d (Cat r1 r2)   = showParen (d > 7) $  -- prec(Cat) = 7
                              showsPrec 7 r1 .
                              showsPrec 7 r2
  showsPrec d (Star r1)     = showsPrec 9 r1 .     -- prec(Star) = 8
                              showString "*"
           
match1 :: RE -> [Char] -> Bool
match1 r w = case r of
              Empty       -> False
              Letter c    -> w == [c]
              Union r1 r2 -> match1 r1 w || match1 r2 w
              Cat r1 r2   -> anymatch r1 r2 w_splits
              Star r1     -> w == "" || anymatch r1 (Star r1) w_nesplits
            where
              anymatch r1 r2 = any (\(w1,w2) -> match1 r1 w1 && match1 r2 w2)
              w_splits@(_:w_nesplits) = splits w
              splits [] = [([], [])]
              splits w@(x:xs) = ([],w) : map (\(a,b) -> (x:a,b)) (splits xs)
                    
-- continuation-based matching
match2 :: RE -> [Char] -> Bool
match2 r w = matchc r w null where
  matchc :: RE -> [Char] -> ([Char] -> Bool) -> Bool
  matchc Empty w k = False
  matchc (Letter c) [] k = False
  matchc (Letter c) (x:xs) k = c == x && k xs
  matchc (Union r1 r2) w k = matchc r1 w k || matchc r2 w k
  matchc (Cat r1 r2) w k = matchc r1 w (\w' -> matchc r2 w' k)
  matchc r@(Star r1) w k = k w || matchc r1 w (\w' -> w' /= w && matchc r w' k)


-- list-based matching
  
-- lists of REs with two kinds of cons
infixr 5 :*:, :+:
data REs = End | RE :*: REs | RE :+: REs

match3 :: RE -> [Char] -> Bool
match3 r = m (r :*: End) where
  m :: REs -> [Char] -> Bool
  -- Invariant for m
  -- (1) m End w         iff  w = ""
  -- (2) m (r :*: rs) w  iff  w = w1++w2 where w1 in L(r) /\ m rs w2
  -- (3) m (r :+: rs) w  iff  w = w1++w2 where |w1| > 0 /\ w1 in L(r) /\ m rs w2
  m End                  = null
  m (Empty :*: rs)       = const False
  m (Empty :+: rs)       = const False
  m (Letter c :*: rs)    = expect c rs
  m (Letter c :+: rs)    = expect c rs
  m (Union r1 r2 :*: rs) = m (r1 :*: rs) |.| m (r2 :*: rs)
  m (Union r1 r2 :+: rs) = m (r1 :+: rs) |.| m (r2 :+: rs)
  m (Cat r1 r2 :*: rs)   = m (r1 :*: r2 :*: rs)
  m (Cat r1 r2 :+: rs)   = m (r1 :+: r2 :*: rs) |.| m (r1 :*: r2 :+: rs)
  m (Star r1 :*: rs)     = m rs |.| m (r1 :+: Star r1 :*: rs)
  m (Star r1 :+: rs)     = m (r1 :+: Star r1 :*: rs)
  expect c rs [] = False
  expect c rs (x:xs) = x == c && m rs xs
  (m1 |.| m2) w = m1 w || m2 w


-- Quick and dirty postfix regex parser, gives non-exaustive match on error
toRE :: String -> RE
toRE w = toRE' w [] where
  toRE' [] [r] = r
  toRE' ('+':xs) (r2:r1:rs) = toRE' xs (Union r1 r2:rs)
  toRE' ('.':xs) (r2:r1:rs) = toRE' xs (Cat r1 r2:rs)
  toRE' ('*':xs) (r:rs) = toRE' xs (Star r:rs)
  toRE' ('@':xs) rs = toRE' xs (Empty:rs)
  toRE' (x:xs) rs = toRE' xs (Letter x:rs)


-- Tests (time, space)

-- regex
-- string 1:  (#,#)  (#,#)  (#,#)
-- string 2   (#,#)  (#,#)  (#,#)
  
-- regex
  
--Alexander W. Plummer
--106800544


-- Tests (time, space)

regex1  = toRE "b*b*.b*b*.."			 -- match1			 match2			 match3
string11 = "bbbbbbbbbbbbbbbbbbbbbbbbbba" --(0.70, 47092188)	(0.22, 8261684)	(0.30, 13929888)
string12 = "bbbbbba"					 --(0.02, 1032824)	(0.00, 519440)	(0.02, 1036412)
string13 = "aaaaaaaaaaaaaaaaaaaaaaaaaab" --(0.09, 7837224)	(0.00, 520380)	(0.02, 517736)

regex2  = toRE "b*b*.b*b*..a."
string21 = "bbbbbbbbbbbbbbbbbbbbbbbbbba" --(0.02, 1063776)	(0.02, 518656)	(0.02, 517536)
string22 = "bbbbbba"					 --(0.00, 522020)	(0.00, 520044)	(0.00, 520604)
string23 = "aaaaaaaaaaaaaaaaaaaaaaaaaab" --(0.69, 47572136)	(0.00, 518172)	(0.02, 520080)


regex3  = toRE "b*b*+b*b*..b+"
string31 = "bbbbbbbbbbbbbbbbbbbbbbbbbba" --(0.62, 43469528)	(0.06, 2608924)	(0.08, 4156800)
string32 = "bbbbbba"					 --(0.02, 1069632)	(0.00, 517316)	(0.00, 517920)
string33 = "aaaaaaaaaaaaaaaaaaaaaaaaaab" --(0.03, 2097944)	(0.00, 518000)	(0.02, 521192)



{- 
	TRACING:
	
-}











