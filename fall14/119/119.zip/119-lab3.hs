import Data.List (nub)

sig = ['a', 'b']
type FSM =	(
				[Integer], 				--States
				Integer,				--Start State
				[Integer],				--Final States
				[(Integer, Char, Integer)]	--Transitions (Source, Letter, Destination)
			)
states 	(x,_,_,_) = x
start	(_,x,_,_) = x
finals 	(_,_,x,_) = x
trans 	(_,_,_,x) = x
first 	(x,_,_) = x
second	(_,x,_) = x
third 	(_,_,x) = x

pair :: (Integer, Char, Integer) -> (Integer, Char)
pair (x,y,_) = (x,y)

checkTrans :: FSM -> Bool
checkTrans m 	=  and[elem (second j) sig | j<-(trans m)]
				&& length[(x,y)|x<-(states m), y<-sig, elem (x,y) [(pair j)|j<-(trans m)]] == (length ([(pair j)|j<-(trans m)]))
				&& and[elem (third j) (states m) | j<-(trans m)] 
				
checkFSM :: FSM -> Bool
checkFSM m 	=  (nub (states m))==(states m)				-- 1 
			&& (elem (start m) (states m))				-- 2
			&& (and[elem j (states m) | j<-(finals m)])	-- 3
			&& (checkTrans m)
			
			
delta :: FSM -> Integer -> Char -> Integer
delta m q c = [(third n)|n<-(trans m), (first n) == q && (second n) == c] !! 0


delta_star :: FSM -> Integer -> [Char] -> Integer
delta_star m q [s] = delta m q s
delta_star m q (s:ss) = delta_star m (delta m q s) ss  

accept1 :: FSM -> [Char] -> Bool
accept1 m str = (elem (delta_star m (start m) str) (finals m))

accept2_aux :: FSM -> Integer -> [Char] -> Bool
-- accept2_aux m q w = whether m, starting in q, accepts w (recursive in w)
accept2_aux m q [] = (elem q (finals m))
accept2_aux m q (w:ws) = accept2_aux m (delta m q w) ws
--L sub q notes

accept2 :: FSM -> [Char] -> Bool
accept2 m str = accept2_aux m (start m) str

-- Define a machine that accepts exactly the strings with an even number of a's
-- and test it adequately
mEven = ([1,2],1,[1],[(1,'a',2),(2,'a',1),(1,'b',1),(2,'b',2)])


-- Define a machine that accepts exactly the strings that do not contain "aaa"
-- as a substring and test it adequately
mNoaaa = ([1,2,3,4],1,[1,2,3],[(1,'a',2),(1,'b',1),(2,'a',3),(2,'b',1),(3,'a',4),(3,'b',1),(4,'a',4),(4,'b',4)])

