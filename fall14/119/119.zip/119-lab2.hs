import Data.List (nub)

--type String = [Char] --This breaks things
type Language = [String]

strcat :: String -> String -> String
strcat [] [] 		= ""
strcat [] x 		= x
strcat x [] 		= x
strcat (x:xs) (y) 	= x:(strcat xs y)

strlen :: String -> Int
strlen [] 			= 0
strlen [x] 			= 1
strlen (x:xs) 		= 1 + (strlen xs)

concat_lang :: Language -> Language -> Language
concat_lang [] [] 			= []
concat_lang [] x 			= []
concat_lang x []			= []
concat_lang [""] x			= x
concat_lang x [""]			= x
concat_lang (x:xs) (ys) 	= [strcat x j | j <- ys] ++ (concat_lang xs ys) 

power_lang :: Language -> Int -> Language
power_lang _ 0 	= [""]
power_lang x 1 	= x
power_lang x n 	= concat_lang x (power_lang x (n-1))

union_lang :: Language -> Language -> Language
union_lang [] [] 			= []
union_lang x [] 			= x
union_lang [] x 			= x
union_lang (x:xs) (y:ys) 	= nub(x : y : (union_lang xs ys))

bstar_lang :: Language -> Int -> Language
bstar_lang _ 0 	= []
bstar_lang x 1 	= x
bstar_lang x n 	= (union_lang (bstar_lang (power_lang x n) (n-1)) x) 

element :: String -> Language -> Bool
element _ [] 	= False
element s x  	= or[s==j|j<-x] 

subset :: Language -> Language -> Bool
subset [] [] 	= True
subset _ [] 	= True
subset [] _ 	= False
subset x y 		= and[element j y | j<-x]

data RegExp = Empty
             | Str String
             | Cat RegExp RegExp
             | Union RegExp RegExp
             | BStar RegExp Int

lang_of :: RegExp -> Language
lang_of (Empty) 	= []
lang_of (Str s) 	= [s]
lang_of (Cat x y) 	= concat_lang (lang_of x) (lang_of y)
lang_of (Union x y) = union_lang  (lang_of x) (lang_of y)
lang_of (BStar x n) = bstar_lang  (lang_of x) n

