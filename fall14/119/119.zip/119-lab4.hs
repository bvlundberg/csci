-- Alexander W. Plummer Lab4 Submission
-- ID 106800544

-- Lab 4: Convert regular expressions to FSMs
-- Contains solutions to Lab 2 and Lab 3

{-#LANGUAGE GADTs, StandaloneDeriving #-}   -- required for defn. of RegExp a

import Data.List (nub, sort, subsequences, isInfixOf)


-- Fixed alphabet, but everything below should work for any sigma!
sigma = ['a', 'b']   

-- Type of states for the machines accepting the empty set and single letter
data EmptyFSM = Etrap  deriving (Show, Eq, Ord)
data LetterFSM = Lstart | Lfinal | Ltrap  deriving (Show, Eq, Ord)
                                             
-- Regular expressions indexed by the type of their associated FSMs
data RegExp a where
  Empty  :: RegExp EmptyFSM
  Letter :: Char -> RegExp LetterFSM
  Union  :: (Eq a, Eq b) => RegExp a -> RegExp b -> RegExp (a, b)
  Cat    :: (Eq a, Ord b) => RegExp a -> RegExp b -> RegExp (a, [b])
  Star   :: Ord a => RegExp a -> RegExp [a]
deriving instance Show (RegExp a)


---------------- Solution to Lab 2, ported to this datatype ----------------
  
-- type String = [Char]
type Language = [String]

strcat :: String -> String -> String
strcat [] ys = ys
strcat (x:xs) ys = x : strcat xs ys
-- but we'll use "++" below for efficiency                   

strlen :: String -> Int
strlen [] = 0
strlen (x:xs) = 1 + strlen xs
-- but we'll use "length" below for efficiency

concat_lang :: Language -> Language -> Language
concat_lang xs ys = nub [w ++ s | w <- xs, s <- ys]

power_lang :: Language -> Int -> Language
power_lang xs 0 = [""]
power_lang xs n = concat_lang xs (power_lang xs (n - 1))                  
                    
union_lang :: Language -> Language -> Language
union_lang xs ys = nub (xs ++ ys)

bstar_lang :: Language -> Int -> Language
bstar_lang xs n = concat (scanl concat_lang [""] (replicate n xs))


---------------- Solution to Lab 3, ported to this datatype ----------------
  
-- Finite state machines indexed by the type of their states
-- (states, start, final, transitions)  
type FSM a = ([a], a, [a], [(a, Char, a)])

-- no_dups xs = "xs has no duplicates"
no_dups :: Eq a => [a] -> Bool
no_dups [] = True           
no_dups (x:xs) = not (elem x xs) && no_dups xs

-- subset xs ys == "xs is a subset of ys"
subset :: Eq a => [a] -> [a] -> Bool
subset [] ys = True
subset (x:xs) ys = elem x ys && subset xs ys

-- single xs ys == "xs has a unique element, which is in ys"
single :: Eq a => [a] -> [a] -> Bool
single [x] ys = elem x ys
signle _ _ = False                

-- func3 as bs ts == "ts determines a function from (as x bs) to cs"
func3 :: (Eq a, Eq b, Eq c) => [a] -> [b] -> [c] -> [(a,b,c)] -> Bool
func3 as bs cs ts = and [single (thirds a b ts) cs | a <- as, b <- bs] where
  thirds a b ts = [c' | (a',b',c') <- ts, a' == a, b' == b]
  single [x] ys = elem x ys
  single _ _ = False

-- check whether a finite state machine is correct/complete:
checkFSM :: Eq a => FSM a -> Bool
checkFSM (qs, q0, fs, d) = no_dups qs &&        -- (1)
                           elem q0 qs &&        -- (2)
                           subset fs qs &&      -- (3)
                           func3 qs sigma qs d  -- (4)
                           

-- All functions below assume that the machine is correct

-- ap ts q a == the unique q' such that (q, a, q') is in ts;  assumes success
ap :: Eq a => [(a,Char,a)] -> a -> Char -> a 
ap ((q1, a1, q2):ts) q a | q1 == q && a1 == a = q2
                             | otherwise = ap ts q a

delta :: Eq a => FSM a -> a -> Char -> a
delta (_, _, _, d) = ap d
                                             
delta_star :: Eq a => FSM a -> a -> [Char] -> a
delta_star = foldl . delta

accept1 :: Eq a => FSM a -> [Char] -> Bool
accept1 m@(qs, q0, fs, d) w = elem (delta_star m q0 w) fs

accept2_aux :: Eq a => FSM a -> a -> [Char] -> Bool
accept2_aux m@(_, _, fs, _) q [] = elem q fs
accept2_aux m q (a:w) = accept2_aux m (delta m q a) w

accept2 :: Eq a => FSM a -> [Char] -> Bool
accept2 m@(_, q0, _, _) w = accept2_aux m q0 w


-- even_as is a machine that accepts strings with an even number of a's
-- states: (number of a's read so far) mod 2
even_as :: FSM Int
even_as = ([0,1], 0, [0], [(i, a, d i a) | i <- [0,1], a <- sigma]) where
  d i 'a' = (i + 1) `mod` 2
  d i 'b' = i

-- for testing, this function accepts the same strings as even_as
even_as' :: [Char] -> Bool
even_as' xs = (length (filter (=='a') xs)) `mod` 2 == 0

-- no_aaa is a machine that accepts strings that don't have three a's in a row
-- states: number of a's in a row just read (n = 0, 1, 2), 3 is a trap
no_aaa :: FSM Int
no_aaa = ([0..3], 0, [0..2], [(i, a, d i a) | i <- [0..3], a <- sigma]) where
  d i 'a' = min 3 (i + 1)
  d 3 'b' = 3
  d _ 'b' = 0

-- for testing, this function accepts the same strings as no_aaa
no_aaa' = not . isInfixOf "aaa"


---------------- Lab 4 begins here -----------------------------------------

-- Some helpful functions

(><) :: [a] -> [b] -> [(a,b)]              -- Cartesian product
xs >< ys = [(x,y) | x <- xs, y <- ys]   

overlap :: Eq a => [a] -> [a] -> Bool                -- overlap
overlap [] ys = False
overlap (x:xs) ys = elem x ys || overlap xs ys

-- Machine that accepts the empty language
emptyFSM :: FSM EmptyFSM
emptyFSM = ([Etrap], Etrap, [], [(Etrap, a, Etrap) | a <- sigma])

removeElem :: Char -> [Char] -> [Char]
removeElem x j = [k|k<-j,x/=k]	 

-- Machine that accepts the language {"a"} where a in sigma
letterFSM :: Char -> FSM LetterFSM
letterFSM c = 	(	[Lstart,Lfinal,Ltrap],
					Lstart,
					[Lfinal],
					(Lstart,c,Lfinal):(Lfinal,c,Ltrap):(Ltrap,c,Ltrap):[(q,j,Ltrap)|q<-[Lstart,Lfinal,Ltrap],j<-(removeElem c sigma)]
				)    

first 	(x,_,_) = x
second	(_,x,_) = x
third 	(_,_,x) = x
              
-- Machine that accepts the union of the languages accepted by m1 and m2
unionFSM :: (Eq a, Eq b) => FSM a -> FSM b -> FSM (a, b)
unionFSM (q1, s1, f1, t1) (q2, s2, f2, t2) = 	
	(	((><)(q1) (q2)),
		(s1, s2),
		nub(((><)q1 f2) ++ ((><)f1 q2)),
		nub[(((first a),(first b)),c,((delta (q1, s1, f1, t1) (first a) c),(delta (q2, s2, f2, t2) (first b) c)))|a<-t1, b<-t2, c<-sigma]
	)
	
	
-- Machine that accepts the concatenation of the languages accepted by m1 and m2
catFSM :: (Eq a, Ord b) => FSM a -> FSM b -> FSM (a, [b])
catFSM (q1, s1, f1, t1) (q2, s2, f2, t2) =
	(	((><) q1 (subsequences q2)),
		(if (elem s1 f1) then (s1,[s2]) else (s1,[])),
		[(a,j)|a<-q1, j<-subsequences(q2), overlap j f2],
		[ 	((q,j),c,(if (elem (delta (q1, s1, f1, t1) q c) f1) then
						((delta (q1, s1, f1, t1) q c),nub([s2]++([delta (q2, s2, f2, t2) b c |b<-j])))
					else 
						((delta (q1, s1, f1, t1) q c),sort $ nub $ [delta (q2, s2, f2, t2) b c |b<-j])
					)
			)
		|q<-q1,c<-sigma,j<-subsequences(q2)]
	)
	
-- Machine that accepts the Kleene star of the language accepted by m1
starFSM :: Ord a => FSM a -> FSM [a]
starFSM (q1, s1, f1, t1) = (
							nub (subsequences q1),
							[],
							[bs|bs<-(subsequences q1), overlap bs f1]++[],
								[if bs == [] then 
									(bs,c,[(delta (q1, s1, f1, t1) s1 c)])
								else
									  (bs,c,sort(nub ([delta (q1, s1, f1, t1) b c|b<-bs]
									++ [s1|b<-bs, elem (delta (q1, s1, f1, t1) b c) f1])))
							|bs<-(subsequences q1),c<-sigma]
							)

-- After defining the functions above, uncomment all of the following:
conv :: RegExp a -> FSM a
conv (Empty) = emptyFSM
conv (Letter c) = letterFSM c
conv (Union r1 r2) = unionFSM (conv r1) (conv r2)
conv (Cat r1 r2) = catFSM (conv r1) (conv r2)
conv (Star r1) = starFSM (conv r1)