-- Solution to Lab 4: Convert regular expressions to FSMs
-- Contains solutions to Lab 2 and Lab 3
--
-- Note: the bonus feature at the end (i.e., conv') required changing
-------- the type constraints on union and cat throughout to (Ord a)

{-#LANGUAGE GADTs, StandaloneDeriving #-}   -- required for defn. of RegExp a

import Data.List (nub, sort, subsequences, isInfixOf)


-- Fixed alphabet, but everything below should work for any sigma!
sigma = ['a', 'b']   

-- Type of states for the machines accepting the empty set and single letter
data EmptyFSM = Etrap  deriving (Show, Eq, Ord)
data LetterFSM = Lstart | Lfinal | Ltrap  deriving (Show, Eq, Ord)
                                             
-- Regular expressions indexed by the state-type of their associated FSMs
data RegExp a where
  Empty  :: RegExp EmptyFSM
  Letter :: Char -> RegExp LetterFSM
  Union  :: (Ord a, Ord b) => RegExp a -> RegExp b -> RegExp (a, b)
  Cat    :: (Ord a, Ord b) => RegExp a -> RegExp b -> RegExp (a, [b])
  Star   :: Ord a => RegExp a -> RegExp [a]
deriving instance Show (RegExp a)


---------------- Solution to Lab 2, ported to this datatype ----------------
  
-- type String = [Char]
type Language = [String]

strcat :: String -> String -> String
strcat [] ys = ys
strcat (x:xs) ys = x : strcat xs ys
-- but we'll use "++" below for efficiency                   

strlen :: String -> Int
strlen [] = 0
strlen (x:xs) = 1 + strlen xs
-- but we'll use "length" below for efficiency

concat_lang :: Language -> Language -> Language
concat_lang xs ys = nub [w ++ s | w <- xs, s <- ys]

power_lang :: Language -> Int -> Language
power_lang xs 0 = [""]
power_lang xs n = concat_lang xs (power_lang xs (n - 1))                  
                    
union_lang :: Language -> Language -> Language
union_lang xs ys = nub (xs ++ ys)

bstar_lang :: Language -> Int -> Language
bstar_lang xs n = concat (scanl concat_lang [""] (replicate n xs))


---------------- Solution to Lab 3, ported to this datatype ----------------
  
-- Finite state machines indexed by the type of their states
-- (states, start, final, transitions)  
type FSM a = ([a], a, [a], [(a, Char, a)])

-- no_dups xs = "xs has no duplicates"
no_dups :: Eq a => [a] -> Bool
no_dups [] = True           
no_dups (x:xs) = not (elem x xs) && no_dups xs

-- subset xs ys == "xs is a subset of ys"
subset :: Eq a => [a] -> [a] -> Bool
subset [] ys = True
subset (x:xs) ys = elem x ys && subset xs ys

-- func3 as bs ts == "ts determines a function from (as >< bs) to cs"
func3 :: (Eq a, Eq b, Eq c) => [a] -> [b] -> [c] -> [(a,b,c)] -> Bool
func3 as bs cs ts = and [single (thirds a b ts) cs | a <- as, b <- bs] where
  thirds a b ts = [c' | (a',b',c') <- ts, a' == a, b' == b]
  single [x] ys = elem x ys
  single _ _ = False

-- check whether a finite state machine is correct/complete:
checkFSM :: Eq a => FSM a -> Bool
checkFSM (qs, q0, fs, d) = no_dups qs &&        -- (1)
                           elem q0 qs &&        -- (2)
                           subset fs qs &&      -- (3)
                           func3 qs sigma qs d  -- (4)
                           

-- All functions below assume that the machine is correct

-- ap ts q a == the unique q' such that (q, a, q') is in ts;  assumes success
ap :: Eq a => [(a,Char,a)] -> a -> Char -> a 
ap ((q1, a1, q2):ts) q a | q1 == q && a1 == a = q2
                             | otherwise = ap ts q a

delta :: Eq a => FSM a -> a -> Char -> a
delta (_, _, _, d) = ap d
                                             
delta_star :: Eq a => FSM a -> a -> [Char] -> a
delta_star = foldl . delta

accept1 :: Eq a => FSM a -> [Char] -> Bool
accept1 m@(qs, q0, fs, d) w = elem (delta_star m q0 w) fs

accept2_aux :: Eq a => FSM a -> a -> [Char] -> Bool
accept2_aux m@(_, _, fs, _) q [] = elem q fs
accept2_aux m q (a:w) = accept2_aux m (delta m q a) w

accept2 :: Eq a => FSM a -> [Char] -> Bool
accept2 m@(_, q0, _, _) w = accept2_aux m q0 w


-- even_as is a machine that accepts strings with an even number of a's
-- states: (number of a's read so far) mod 2
even_as :: FSM Int
even_as = ([0,1], 0, [0], [(i, a, d i a) | i <- [0,1], a <- sigma]) where
  d i 'a' = (i + 1) `mod` 2
  d i 'b' = i

-- for testing, this function accepts the same strings as even_as
even_as' :: [Char] -> Bool
even_as' xs = (length (filter (=='a') xs)) `mod` 2 == 0

-- no_aaa is a machine that accepts strings that don't have three a's in a row
-- states: number of a's in a row just read (n = 0, 1, 2), 3 is a trap
no_aaa :: FSM Int
no_aaa = ([0..3], 0, [0..2], [(i, a, d i a) | i <- [0..3], a <- sigma]) where
  d i 'a' = min 3 (i + 1)
  d 3 'b' = 3
  d _ 'b' = 0

-- for testing, this function accepts the same strings as no_aaa
no_aaa' = not . isInfixOf "aaa"


---------------- Lab 4 begins here -----------------------------------------

-- Some helpful functions

(><) :: [a] -> [b] -> [(a,b)]              -- Cartesian product
xs >< ys = [(x,y) | x <- xs, y <- ys]   

overlap :: Eq a => [a] -> [a] -> Bool      -- have inhabited intersection
overlap [] ys = False
overlap (x:xs) ys = elem x ys || overlap xs ys


-- Machine that accepts the empty language
emptyFSM :: FSM EmptyFSM
emptyFSM = ([Etrap], Etrap, [], [(Etrap, a, Etrap) | a <- sigma])

-- Machine that accepts the language {"a"} where a in sigma
letterFSM :: Char -> FSM LetterFSM
letterFSM a = ([Lstart, Lfinal, Ltrap], Lstart, [Lfinal],
              [(q, a', if q == Lstart && a' == a then Lfinal else Ltrap) |
               q <- [Lstart, Lfinal, Ltrap], a' <- sigma])
              
-- Machine that accepts the union of the languages accepted by m1 and m2
unionFSM :: (Ord a, Ord b) => FSM a -> FSM b -> FSM (a, b)
unionFSM (qs1, q01, fs1, d1) (qs2, q02, fs2, d2) = (qs, q0, fs, d) where
  qs = qs1 >< qs2
  q0 = (q01, q02)
  fs = [q | q <- qs, elem (fst q) fs1 || elem (snd q) fs2]
  d  = [(q, a, step q a) | q <- qs, a <- sigma]
  step (q1, q2) a = (ap d1 q1 a, ap d2 q2 a)

-- Machine that accepts the concatenation of the languages accepted by m1 and m2
catFSM :: (Ord a, Ord b) => FSM a -> FSM b -> FSM (a, [b])
catFSM (qs1, q01, fs1, d1) (qs2, q02, fs2, d2) = (qs, q0, fs, d) where
  qs = qs1 >< subsequences qs2
  q0 = (q01, [q02 | elem q01 fs1])
  fs = [q | q <- qs, overlap (snd q) fs2]
  d  = [(q, a, step q a) | q <- qs, a <- sigma]
  step (q1, b) a = (q1', b') where
    q1' = ap d1 q1 a
    b'  = nub $ sort $ [q02 | elem q1' fs1] ++ map (\q2 -> ap d2 q2 a) b

-- Machine that accepts the Kleene star of the language accepted by m1
starFSM :: Ord a => FSM a -> FSM [a]
starFSM (qs, q0, fs, d) = (qs', q0', fs', d') where
  qs' = subsequences qs
  q0' = []
  fs' = [q' | q' <- qs', q' == [] || overlap q' fs]
  d'  = [(q', a, step q' a) | q' <- qs', a <- sigma]
  step [] a = nub $ sort $ [q0 | elem q fs] ++ [q] where q = ap d q0 a
  step b a  = let b' = map (\q -> ap d q a) b
              in nub $ sort $ [q0 | overlap b' fs] ++ b'
    
-- Conversion function
conv :: RegExp a -> FSM a
conv Empty = emptyFSM
conv (Letter c) = letterFSM c
conv (Union r1 r2) = unionFSM (conv r1) (conv r2)
conv (Cat r1 r2) = catFSM (conv r1) (conv r2)
conv (Star r1) = starFSM (conv r1)


-------------------------------------------------------------------------
-- Bonus feature:  a much more frugal conversion function that eliminates
-- dead (i.e., unreachable) states from the resulting machine

-- reachable m == the part of m that is reachable from the start state
reachable :: Ord a => FSM a -> FSM a
reachable m@(qs, q0, fs, d) = (qs', q0, fs', d') where
  qs' = sort $ stable $ iterate close ([q0], [])
  fs' = filter (`elem` qs') fs
  d'  = filter (\(q,_,_) -> q `elem` qs') d
  stable ((fr,qs):rest) = if null fr then qs else stable rest
  close (fr, xs) = (fr', xs') where
    xs' = fr ++ xs
    fr' = nub $ filter (`notElem` xs') (concatMap step fr)
    step q = map (ap d q) sigma

-- a better conversion
conv' :: RegExp a -> FSM a
conv' Empty = emptyFSM
conv' (Letter c) = letterFSM c
conv' (Union r1 r2) = reachable $ unionFSM (conv' r1) (conv' r2)
conv' (Cat r1 r2) = reachable $ catFSM (conv' r1) (conv' r2)
conv' (Star r1) = reachable $ starFSM (conv' r1)



removeElem :: Char -> [Char] -> [Char]
removeElem x j = [k|k<-j,x/=k]

stringFSM :: [Char] -> FSM Int
stringFSM w = (qs, q0, fs, ts) where
		 qs = [x|x<-[0 .. (length w)]]
		 q0 = 1
		 fs = [(length w)]
		 ts = [(c,w!!c,c+1)|c<-[1..((length w)-1)]] ++ (foldl (++) [((fromIntegral 0),'a',(fromIntegral 0))][[(c,sig,0)|sig<-(removeElem (w!!c) sigma)]|c<-[1..((length w)-1)]])
			
			
			
			
			
			
			
			
			
			

