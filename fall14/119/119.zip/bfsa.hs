import Data.List (nub)
import Control.Monad (replicateM)

-- Two useful list functions
(\/) :: Eq a => [a] -> [a] -> [a]    -- Union of lists
xs \/ ys = nub $ xs ++ ys

(?) :: Bool -> [a] -> [a]            -- Optional list
True ? xs = xs
False ? _ = []


-- Regular expressions
data RE = Empty | Letter Char | Union RE RE | Cat RE RE | Star RE
instance (Show RE) where    -- use precedence to minimize parentheses
  showsPrec d Empty         = showString "@"
  showsPrec d (Letter c)    = showString [c]
  showsPrec d (Union r1 r2) = showParen (d > 6) $  -- prec(Union) = 6
                              showsPrec 6 r1 .
                              showString "+" .
                              showsPrec 6 r2
  showsPrec d (Cat r1 r2)   = showParen (d > 7) $  -- prec(Cat) = 7
                              showsPrec 7 r1 .
                              showsPrec 7 r2
  showsPrec d (Star r1)     = showsPrec 9 r1 .     -- prec(Star) = 8
                              showString "*"

-- continuation-based matching
match2 :: RE -> [Char] -> Bool
match2 r w = matchc r w null where
  matchc :: RE -> [Char] -> ([Char] -> Bool) -> Bool
  matchc Empty w k = False
  matchc (Letter c) [] k = False
  matchc (Letter c) (x:xs) k = c == x && k xs
  matchc (Union r1 r2) w k = matchc r1 w k || matchc r2 w k
  matchc (Cat r1 r2) w k = matchc r1 w (\w' -> matchc r2 w' k)
  matchc r@(Star r1) w k = k w || matchc r1 w (\w' -> w' /= w && matchc r w' k)


-- list-based matching
  
-- lists of REs with two kinds of cons
infixr 5 :*:, :+:
data REs = End | RE :*: REs | RE :+: REs deriving Show

match3 :: RE -> [Char] -> Bool
match3 r = m (r :*: End) where
  m :: REs -> [Char] -> Bool
  -- Invariant for m
  -- (1) m End w         iff  w = ""
  -- (2) m (r :*: rs) w  iff  w = w1++w2 where w1 in L(r) /\ m rs w2
  -- (3) m (r :+: rs) w  iff  w = w1++w2 where |w1| > 0 /\ w1 in L(r) /\ m rs w2
  m End w                  = null w
  m (Empty :*: rs) w       = False
  m (Empty :+: rs) w       = False
  m (Letter c :*: rs) w    = expect c w && m rs (tail w)
  m (Letter c :+: rs) w    = expect c w && m rs (tail w)
  m (Union r1 r2 :*: rs) w = m (r1 :*: rs) w || m (r2 :*: rs) w
  m (Union r1 r2 :+: rs) w = m (r1 :+: rs) w || m (r2 :+: rs) w
  m (Cat r1 r2 :*: rs) w   = m (r1 :*: r2 :*: rs) w
  m (Cat r1 r2 :+: rs) w   = m (r1 :+: r2 :*: rs) w || m (r1 :*: r2 :+: rs) w
  m (Star r1 :*: rs) w     = m rs w || m (r1 :+: Star r1 :*: rs) w
  m (Star r1 :+: rs) w     = m (r1 :+: Star r1 :*: rs) w
  expect c [] = False
  expect c (x:_) = x == c


-- Backward FSMs.  A valid BFSM (ms, ts) requires that
-- (1) ms (the set of initial states) has no duplicates
-- (2) ts (the set of transitions) has no duplicates
type BFSM = ([Int], [(Int,Char,[Int])])

-- check that a BFSM is valid
checkBFSM :: BFSM -> Bool
checkBFSM (ms, ts) = no_dups ms && tr_no_dups ts

-- no duplicate elements
no_dups :: [Int] -> Bool
no_dups [] = True           
no_dups (x:xs) = notElem x xs && no_dups xs

-- no duplicate transitions
tr_no_dups :: [(Int,Char,[Int])] -> Bool
tr_no_dups [] = True
tr_no_dups ((n,a,ns):ts) = no_dups ns &&
                           notElem (n,a) [(n,a) | (n,a,_) <- ts] &&
                           tr_no_dups ts


-- Acceptance of strings by BFSMs

-- ap ts q a == non-deterministic transition from q on a using ts
ap :: [(Int,Char,[Int])] -> Int -> Char -> [Int]
ap [] q c = []
ap ((n,a,ns):ts) q c | q == n && c == a = ns
                     | otherwise = ap ts q c

aps :: [(Int,Char,[Int])] -> Int -> [Char] -> [Int]
aps ts q [] = [q]
aps ts q (a:as) = nub . concat . map (\n -> aps ts n as) $ ap ts q a

delta :: BFSM -> Int -> Char -> [Int]
delta (_, ts) = ap ts

delta_star :: BFSM -> Int -> [Char] -> [Int]
delta_star (_, ts) = aps ts

accept :: BFSM -> [Char] -> Bool
accept (ms,ts) w = elem 0 . concat $ map (\n -> aps ts n w) ms


-- Conversion
conv :: RE -> BFSM
conv r = (b?[0]\/ms,ts) where ((ms,ts),_,b) = conv' r [1..] ([0],[])

-- Specification for conv' r ss m = (m', ss', b) 
-- Assumes:
--   (1) ss is an infinite list of integers with no duplicates
--   (2) none of the states in m are in ss
--   (3) m is a valid BFSM
-- Ensures:
--   (1) m' is a valid BFSM
--   (2) L(m') = L(r) * L(m)
--   (3) ss' is a final segment of ss, and none of the states of m' are in ss'
--   (4) b == True iff "" in L(m')
conv' :: RE -> [Int] -> BFSM -> (BFSM, [Int], Bool)
conv' Empty ss m = (([],[]), ss, False)
conv' (Letter c) (s:ss) (ms,ts) = (([s],[(s,c,ms)]), ss, False)
conv' (Union r1 r2) ss m =
  let ((ms2,ts2), ss',  b2) = conv' r2 ss  m
      ((ms1,ts1), ss'', b1) = conv' r1 ss' m
  in ((ms2\/ms1,ts2\/ts1), ss'', b2||b1)
conv' (Cat r1 r2) ss m@(ms,ts) =     
  let ((ms2,ts2), ss',  b2) = conv' r2 ss m
      ((ms1,ts1), ss'', b1) = conv' r1 ss' (b2?ms\/ms2,ts2)
  in ((b1?ms2\/ms1,ts2\/ts1), ss'', b2&&b1)
conv' (Star r1) ss m@(ms,ts) =
  let ((ms1,ts1), ss', _) = conv' r1 ss (ms1\/ms,ts)
  in ((ms1,ts1), ss', True)
                                    

-- Quick and dirty postfix regex parser, gives non-exaustive match on error
toRE :: String -> RE
toRE w = toRE' w [] where
  toRE' [] [r] = r
  toRE' ('+':xs) (r2:r1:rs) = toRE' xs (Union r1 r2:rs)
  toRE' ('.':xs) (r2:r1:rs) = toRE' xs (Cat r1 r2:rs)
  toRE' ('*':xs) (r:rs) = toRE' xs (Star r:rs)
  toRE' ('@':xs) rs = toRE' xs (Empty:rs)
  toRE' (x:xs) rs = toRE' xs (Letter x:rs)
     
                    
-- A test                    

-- All strings over "ab" of length 10 or less
strings = concat $ [replicateM i "ab" | i <- [0..10]]

-- Some regular expressions
regexes = map toRE ["ab+*a.ab+*.ab+*.",   -- third to last letter is a
                    "b*a.b*.a.*b*.",      -- even number of a's
                    "aba.+*b.b.aab.+*."]  -- contains bb exactly once

-- Test each regex against each string using both match2 and accept
test = [(r,w) | r<-regexes, let m = conv r, w<-strings, accept m w /= match2 r w]