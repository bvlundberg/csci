
import Control.Monad (replicateM)

strings = concat $ [replicateM i "ab" | i <- [0..15]]



mysplit s = [((take n s),(drop n s))|n<-[0..(length s)]]

splits [] = [([], [])]
splits w@(x:xs) = ([],w) : map (\(a,b) -> (x:a,b)) (splits xs)




test1 = sum[length(splits s) | s <- strings]
test2 = sum[length(mysplit s) | s <- strings]