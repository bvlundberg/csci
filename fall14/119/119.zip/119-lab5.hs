data RE = 	 Empty
			|Letter Char
			|Union RE RE
			|Cat RE RE
			|Star RE
instance (Show RE) where
	show Empty = "@"
	show (Letter c) = [c]
	show (Union r1 r2) = "("++show r1 ++"+"++ show r2++")"
	show (Cat r1 r2) = "("++show r1 ++"."++ show r2++")"
	show (Star r) = "("++show r++")*"
			
match :: RE -> [Char] -> Bool
match r w = match' r w null
			
-- ([Char] -> Bool) = continuation
match' :: RE -> [Char] -> ([Char] -> Bool) -> Bool
match' Empty w k			= False
match' (Letter c) [] k		= False
match' (Letter c) (x:xs) k	= (x == c) && (k xs)
match' (Union r1 r2) w k	= (match' r1 w k) || (match' r2 w k)
match' (Cat r1 r2) w k		= (match' r1 w (\w' -> (match' r2 w' k)))
match' (Star r1) w k 		= (w==[]) || (match' r1 w (\w' -> (w/=w') && (match' (Star r1) w' k)))

toRE :: [Char] -> RE
toRE w = toRE' w []

toRE' :: [Char] -> [RE] -> RE
toRE' ('+':w) (r2:r1:rs)= toRE' w ((Union r1 r2):rs)
toRE' ('.':w) (r2:r1:rs)= toRE' w ((Cat r1 r2):rs)
toRE' ('*':w) (r1:rs)	= toRE' w ((Star r1):rs)
toRE' ('@':w) rs		= toRE' w (Empty:rs)
toRE' (c:w)   rs		= toRE' w ((Letter c):rs)
toRE' []	  [r]		= r
