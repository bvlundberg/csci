---- CSci 119 Assignment 1, Part 1 (Lab 1) ----
-- Alexander W. Plummer
-- 106800544
-- During lab period: Got stuck on transitive relation, finished everything before it.

---- Boolean operators

bools = [True, False]
and_commutes = and [(p && q) == (q && p) | p <- bools, q <- bools]
or_commutes = and [(p || q) == (q || p) | p <- bools, q <- bools]
and_assoc = and [((p && q) && r ) == (p && (q && r)) | p <- bools, q <- bools, r <- bools] 
or_assoc = and [((p || q) || r ) == (p || (q || r)) | p <- bools, q <- bools, r <- bools] 
and_dist = and [( p && ( q && r ) ) == (( p && q ) && ( p && r )) | p <- bools, q <- bools, r <- bools] 
or_dist = and [( p || ( q || r ) ) == (( p || q ) || ( p || r )) | p <- bools, q <- bools, r <- bools] 

-- XOR Operator       
(^$) :: Bool -> Bool -> Bool
True  ^$ False = True
True  ^$ True  = False
False ^$ False = False 
False ^$ True  = True

-- xor_commutes = True
xor_commutes = and [(p ^$ q) == (q ^$ p) | p <- bools, q <- bools]
-- xor_assoc    = True
xor_assoc = and [((p ^$ q) ^$ r ) == (p ^$ (q ^$ r)) | p <- bools, q <- bools, r <- bools] 
-- xor_dist_and = False
xor_dist_and = and [( p ^$ ( q && r ) ) == (( p ^$ q ) && ( p ^$ r )) | p <- bools, q <- bools, r <- bools] 
-- xor_dist_or  = False
xor_dist_or = and [( p ^$ ( q || r ) ) == (( p ^$ q ) || ( p ^$ r )) | p <- bools, q <- bools, r <- bools] 
-- and_dist_xor = True
and_dist_xor = and [( p && ( q ^$ r ) ) == (( p && q ) ^$ ( p && r )) | p <- bools, q <- bools, r <- bools] 
-- or_dist_xor  = False
or_dist_xor = and [( p || ( q ^$ r ) ) == (( p || q ) ^$ ( p || r )) | p <- bools, q <- bools, r <- bools] 


----- Relations

-- A relation R on a set A of integers can be represented by giving
-- the elements of A as a list, along with a list of the ordered pairs in R:
type Reln = ([Int], [(Int,Int)])
              
-- For example, here are the < and <= relations on the set {1,2,3,4}:          
less_reln :: Reln
less_reln = ([1,2,3,4], [(i,j) | j <- [1..4], i <- [1..j-1]])

leq_reln :: Reln
leq_reln  = ([1,2,3,4], [(i,j) | j <- [1..4], i <- [1..j]])
            			
-- Write a function refl that tests whether a relation is reflexive:
refl :: Reln -> Bool
refl r = and [elem (x,x) (snd r) | x <- (fst r)]

-- Write a function symm that tests whether a relation is symmetric:
symm :: Reln -> Bool
symm r = and [	((elem (x,y) (snd r)) && (elem (y,x) (snd r)))   	-- IF both (x,y) and (y,x) are in the relation
				||													-- OR
				(not(elem (x,y) (snd r)) && not(elem (y,x) (snd r)))-- IF both (x,y) and (y,x) are not in the relation
				| x <- (fst r), y <- (fst r)]

-- Write a function trans that tests whether a relation is transitive:
trans :: Reln -> Bool
trans r = (((length (snd r)) `mod` 2) == 0) --This works... sometimes


-- For each of the 8 possible combinations of yes/no on reflexivity,
-- symmetry, and transitivity, find a minimal relation that has that
-- combination of properties:

-- refl, symm, 
r_s_t 		:: Reln
r_s_t 		= ([1,2,3,4],[(1,1),(2,2),(3,3),(4,4),(1,2),(2,1),(2,3),(1,3),(3,2),(3,1)])

-- refl, symm, not trans
r_s_nt 		:: Reln
r_s_nt 		= ([1,2,3,4],[(1,1),(2,2),(3,3),(4,4),(1,2),(2,1),(2,3),(3,2)])

-- refl, not symm, trans
r_ns_t 		:: Reln
r_ns_t 		= ([1,2,3,4],[(1,1),(2,2),(3,3),(4,4),(1,2),(2,3),(1,3)])

-- refl, not symm, not trans
r_ns_nt 	:: Reln
r_ns_nt 	= ([1,2,3,4],[(1,1),(2,2),(3,3),(4,4),(1,2)])

-- not refl, symm, trans
nr_s_t 		:: Reln
nr_s_t 		= []   --([1,2,3,4],[(1,2),(1,3),(2,1),(2,2),(2,3),(3,1),(3,2),(3,3)])

-- not refl, symm, not trans
nr_s_nt 	:: Reln
nr_s_nt 	= ([1,2,3,4],[(1,2),(2,1)])

-- not refl, not symm, trans
nr_ns_t 	:: Reln
nr_ns_t 	= ([1,2,3,4],[(1,1)])

-- not refl, not symm, not trans
nr_ns_nt 	:: Reln
nr_ns_nt 	= ([1,2,3,4],[(1,2),(2,3)])

---- Functions

-- A function F : A -> B, where A and B are finite sets of integers, can be
-- represented by giving the elements of A as a list, the elements of B as
-- a list, and the list of the ordered pairs in F:
type Funct = ([Int], [Int], [(Int,Int)])

--Tuple helper funcs
first (x,_,_) = x
second(_,x,_) = x
third (_,_,x) = x

--Helper function to get range (With duplicates)
range :: Funct -> [Int]
range f = [snd j | j <- (third f)]

--Functions for testing
testfunc :: Funct
testfunc = ([1,2,3],[1,2,3],[(1,1),(2,2),(3,3)])
notfunc :: Funct
notfunc = ([1,2,3],[1,2,3],[(1,1),(3,3)])

--Test if f is a function
functional :: Funct -> Bool
functional f = length[x|x<-(first f), elem x [(fst j)|j<-(third f)]] == (length (first f)) --Each elem in the domain has exactly one result

--Injective, checks if f is functional
injective :: Funct -> Bool
injective f = (functional f) && and[(length [y | y <- (range f),(x == y)])<2|x<-(first f)]

--Surjective, checks if the range of f is equal to the codomain
surjective :: Funct -> Bool
surjective f = (functional f) && (and[elem x (second f)|x<-(range f)]) && (and[elem x (range f)|x<-(second f)])

--Bijective
bijective :: Funct -> Bool
bijective f = (functional f) && (surjective f) && (injective f)


-- Write a function quotient that computes the equivalence relation generated
-- by a function, quotient :: Funct -> Rel.  For example,
-- quotient ([1,2,3,4], [0,1], [(1,1), (2,0), (3,1), (4,0)]) is
--   = ([1,2,3,4], [(1,1), (1,3), (2,2), (2,4), (3,1), (3,3), (4,2), (4,4)])

app rel x = head (range x rel) --Range defined by TWilson.

quotient :: Funct -> Reln
quotient f = (first f, [(i,j)|i<-(first f),j<-(first f), app (third f) i == app (third f) j])





