-- Regular expressions
import Control.Applicative
import Control.Monad (replicateM)
import Data.Maybe (isJust)  
import Debug.Trace (trace)

data RE = Empty | Letter Char | Union RE RE | Cat RE RE | Star RE
instance (Show RE) where    -- use precedence to minimize parentheses
  showsPrec d Empty         = showString "@"
  showsPrec d (Letter c)    = showString [c]
  showsPrec d (Union r1 r2) = showParen (d > 6) $  -- prec(Union) = 6
                              showsPrec 6 r1 .
                              showString "+" .
                              showsPrec 6 r2
  showsPrec d (Cat r1 r2)   = showParen (d > 7) $  -- prec(Cat) = 7
                              showsPrec 7 r1 .
                              showsPrec 7 r2
  showsPrec d (Star r1)     = showsPrec 9 r1 .     -- prec(Star) = 8
                              showString "*"
           
match1 :: RE -> [Char] -> Bool
match1 r w = case r of
              Empty       -> False
              Letter c    -> w == [c]
              Union r1 r2 -> match1 r1 w || match1 r2 w
              Cat r1 r2   -> anymatch r1 r2 uw_splits
              Star r1     -> w == "" || anymatch r1 (Star r1) w_nesplits
            where
              anymatch r1 r2 = any (\(w1,w2) -> match1 r1 w1 && match1 r2 w2)
              uw_splits@(_:w_nesplits) = splits w
              splits [] = [([], [])]
              splits w@(x:xs) = ([],w) : map (\(a,b) -> (x:a,b)) (splits xs)
                    
-- continuation-based matching
match2 :: RE -> [Char] -> Bool
match2 r w = matchc r w null where
  matchc :: RE -> [Char] -> ([Char] -> Bool) -> Bool
--  matchc r w k | trace (show (r,w)) False = undefined
  matchc Empty w k = False
  matchc (Letter c) [] k = False
  matchc (Letter c) (x:xs) k = c == x && k xs
  matchc (Union r1 r2) w k = matchc r1 w k || matchc r2 w k
  matchc (Cat r1 r2) w k = matchc r1 w (\w' -> matchc r2 w' k)
  matchc r@(Star r1) w k = k w || matchc r1 w (\w' -> w' /= w && matchc r w' k)



-- list-based matching
  
-- lists of REs with two kinds of cons
infixr 5 :*:, :+:
data REs = End | RE :*: REs | RE :+: REs deriving Show

match3 :: RE -> [Char] -> Bool
match3 r = m (r :*: End) where
  m :: REs -> [Char] -> Bool
  -- Invariant for m
  -- (1) m End w         iff  w = ""
  -- (2) m (r :*: rs) w  iff  w = w1++w2 where w1 in L(r) /\ m rs w2
  -- (3) m (r :+: rs) w  iff  w = w1++w2 where |w1| > 0 /\ w1 in L(r) /\ m rs w2
  m End                  = null
  m (Empty :*: rs)       = const False
  m (Empty :+: rs)       = const False
  m (Letter c :*: rs)    = expect c &.& m rs . tail
  m (Letter c :+: rs)    = expect c &.& m rs . tail
  m (Union r1 r2 :*: rs) = m (r1 :*: rs) |.| m (r2 :*: rs)
  m (Union r1 r2 :+: rs) = m (r1 :+: rs) |.| m (r2 :+: rs)
  m (Cat r1 r2 :*: rs)   = m (r1 :*: r2 :*: rs)
  m (Cat r1 r2 :+: rs)   = m (r1 :+: r2 :*: rs) |.| m (r1 :*: r2 :+: rs)
  m (Star r1 :*: rs)     = m rs |.| m (r1 :+: Star r1 :*: rs)
  m (Star r1 :+: rs)     = m (r1 :+: Star r1 :*: rs)
  expect c [] = False
  expect c (x:_) = x == c
  (m1 &.& m2) w = m1 w && m2 w;  infixr 3 &.&
  (m1 |.| m2) w = m1 w || m2 w;  infixr 2 |.|
  

match2' :: RE -> [Char] -> Bool
match2' r w = matchc' r w 0 null where
  matchc' :: RE -> [Char] -> Int -> ([Char] -> Bool) -> Bool
  matchc' r w i k | trace (show (r, i, w)) False = undefined
  matchc' Empty w i k = False
  matchc' (Letter c) [] i k = False
  matchc' (Letter c) (x:xs) i k = c == x && k xs
  matchc' (Union r1 r2) w i k = matchc' r1 w i k || matchc' r2 w i k
  matchc' (Cat r1 r2) w i k = matchc' r1 w (i+1) (\w' -> matchc' r2 w' i k)
  matchc' r@(Star r1) w i k = k w || matchc' r1 w (i+1)
                               (\w' -> w' /= w && matchc' r w' i k)



-- list-based matching with dispositions
-- Below, r :: RE, rs :: [RE], d :: Disp, w :: [Char], and r ~ w means w in L(r)

-- Dispositions:  the "modes" in which we match rs against w
-- N = "null", F = "fail", C = "case"
data Disp = N | F | C Disp Disp deriving Show

match4 :: RE -> [Char] -> Bool
match4 r = m [r] (C N N) where
  -- Invariant for m:
  -- (1) m [] d w iff d = N /\ w = "" (i.e., both rs and w are null)
  -- (2) m rs F w never               (i.e., false; forces backtrack)
  -- (3) m (r:rs) (C d1 d2) w iff exists w1,w2 with w = w1 ++ w2 and r ~ w1 and
  --                         (w1 = "" and m rs d1 w2 or w1 /= "" and m rs d2 w2)
  m :: [RE] -> Disp -> [Char] -> Bool
--  m rs d w | trace (show (rs,d,w)) False = undefined
  m [] N [] = True
  m (Letter c:rs) (C _ d2) (x:xs) = x == c && m rs d2 xs
  m (Union r1 r2:rs) d@(C _ _) w = m (r1:rs) d w || m (r2:rs) d w
  m (Cat r1 r2:rs) d@(C _ d2) w = m (r1:r2:rs) (C d (C d2 d2)) w
  m (Star r1:rs) (C d1 d2) w = m rs d1 w || m (r1:Star r1:rs) (C F (C d2 d2)) w
  m _ _ _ = False


-- Quick and dirty postfix regex parser, gives non-exaustive match on error
toRE :: String -> RE
toRE w = toRE' w [] where
  toRE' [] [r] = r
  toRE' ('+':xs) (r2:r1:rs) = toRE' xs (Union r1 r2:rs)
  toRE' ('.':xs) (r2:r1:rs) = toRE' xs (Cat r1 r2:rs)
  toRE' ('*':xs) (r:rs) = toRE' xs (Star r:rs)
  toRE' ('@':xs) rs = toRE' xs (Empty:rs)
  toRE' (x:xs) rs = toRE' xs (Letter x:rs)


-- Alternative continuation-based matching

-- Continuation "programs"
data Cont = Null | Match RE Cont | MatchNE [Char] RE Cont
instance (Show Cont) where
  show Null = "[]"
  show (Match r k) = show r ++ "||" ++ show k
  show (MatchNE w r k) = show r ++ "|" ++ w ++ "=" ++ show k

match5 :: RE -> [Char] -> Bool
match5 r = matchc r Null where
  matchc :: RE -> Cont -> [Char] -> Bool
  matchc r k w | trace (show (r,w,k)) False = undefined
  matchc Empty k w = False
  matchc (Letter c) k w = expect c w && continue k (tail w)
  matchc (Union r1 r2) k w = matchc r1 k w || matchc r2 k w
  matchc (Cat r1 r2) k w = matchc r1 (Match r2 k) w
  matchc (Star r1) k w = continue k w || matchc r1 (MatchNE w (Star r1) k) w
  
  expect c [] = False
  expect c (x:_) = x == c
  continue Null = null
  continue (Match r k) = matchc r k
  continue (MatchNE w r k) = \w' -> w' /= w && matchc r k w'  




-- Tests (time, space)


-- All strings over "ab" of length 10 or less
strings = concat $ [replicateM i "ab" | i <- [0..10]]

-- Some regular expressions
ab = toRE "aa.bb.+*"
ttla = toRE "ab+*a.ab+.ab+."      -- third to last letter is a
ena  = toRE "b*a.b*.a.*b*."       -- even number of a's
bb1  = toRE "aba.+*b.b.aab.+*."   -- contains bb exactly once
                    
-- Test each regex against each string using both match2 and match4
regexes = [ab, ttla, ena, bb1]
test = take 1 [(r,w) | r<-regexes, w<-strings, match2 r w /= match4 r w]

